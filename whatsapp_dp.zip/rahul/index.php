<html>
    <head>
        <title>
            Display Picture
        </title>
        <script src="/lib/jquery.js"></script> 
    </head>
    <body>
        <form action="upload.php" method="post" enctype="multipart/form-data">
            Select File to Upload:
            <input type="file" name="file" id="file" />
            <input type="submit" name="submit" value="Upload">
        </form>

    </body>
</html>


