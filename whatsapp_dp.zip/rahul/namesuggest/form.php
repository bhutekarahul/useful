<?php
require_once '../connection.php';
?>
<html>
    <head>
        <title>
            Form
        </title>
        <script src="../libs/jquery.js" type="text/javascript"></script>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
    </head>
    <body>
        <div class="container">    
            <div id="signupbox" style=" margin-top:50px" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <div class="panel-title">Sign Up</div>
                        <div style="float:right; font-size: 85%; position: relative; top:-10px"><a id="signinlink" href="/accounts/login/">Sign In</a></div>
                    </div>  
                    <div class="panel-body" >
                        <form method="post" action="." id="register">
                            <div id="div_id_email" class="form-group required">
                                <label for="id_email" class="control-label col-md-4  requiredField"> E-mail<span class="asteriskField">*</span> </label>
                                <div class="controls col-md-8 ">
                                    <input class="input-md emailinput form-control" id="id_email" name="email" placeholder="Your current email address" style="margin-bottom: 10px" type="email" />
                                </div>     
                            </div>
                            <div id="div_id_username" class="form-group required">
                                <label for="id_username" class="control-label col-md-4  requiredField"> Username<span class="asteriskField">*</span> </label>
                                <div class="controls col-md-8 ">
                                    <input class="input-md  textinput textInput form-control" id="id_username" maxlength="30" name="username" placeholder="Choose your username" style="margin-bottom: 10px" type="text" />
                                    <p id="error"></p>
                                </div>
                            </div>
                            <div id="div_id_password1" class="form-group required">
                                <label for="id_password" class="control-label col-md-4  requiredField">Password<span class="asteriskField">*</span> </label>
                                <div class="controls col-md-8 "> 
                                    <input class="input-md textinput textInput form-control" id="id_password1" name="password" placeholder="Create a password" style="margin-bottom: 10px" type="password" />
                                </div>
                            </div>
                            <div class="form-group"> 
                                <div class="aab controls col-md-4 "></div>
                                <div class="controls col-md-8 ">
                                    <input type="submit" name="Signup" value="Signup" class="btn btn-primary btn btn-info" id="submit-id-signup" />
                                </div>
                            </div> 
                        </form>
                    </div>
                </div>
            </div> 
        </div>

        <script>
            $(document).ready(function(){
                $('#id_username').blur(function(){
                    var name = $(this).val();
                    var email = $('#id_email').val();
                    
                    checkname(name,email);
                });
                
                function checkname(name,email)
                {
//                    alert(name);alert(email);
                    $.ajax({
                        url:'validateUsername.php',
                        type:'post',
                        data:{name:name,email:email},
                        success:function(data){
                            var result = JSON.parse(data)
                            if(result.status == "false")
                            {
                                $("#error").html('"'+name+'" username is not availabe.<br>\n\
                                        You can try: '+result.name1+', '+result.name2+', '+result.name3);
                            }
                            else
                            {
                                $("#error").empty();
                            }
                        }
                    })
                }
//                $('#register').validate({
//                   rules:{
//                        email:"required",
//                        username:{
//                            required:true,
//                            'remote':{
//                                url:'validateUsername.php',
//                                type:'post',
//                                data:{
//                                    username: function()
//                                    {
//                                        return $('#register :input[name="username"]').val();
//                                    }
//                                }
//                            }
//                        },
//                        password:"required"
//                   },
//                   messages:{
//                        username:
//                        {
//                           required: "Please enter username.",
//                           remote: "Username not available"
//                        },
//                   }
//                });
            });
        </script>
    </body>
</html>