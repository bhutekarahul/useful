<?php
require_once '../connection.php';

if($_POST['name']){
    $username = $_POST['name'];
    $email = $_POST['email'];

    $query = "SELECT username FROM users WHERE username = '{$username}' LIMIT 1;";
    $results = mysqli_query($conn,$query);
    $detail = mysqli_fetch_assoc($results);
    if(mysqli_num_rows($results) == 0)
    {
        echo "true";  //good to register
    }
    else
    {   
        $parts = explode("@", $email);
        $username = $parts[0];
        
        $name1 = $username.rand(0, 1000);
        $name2 = $username.rand(1000, 2000);
        $name3 = $username.rand(2000, 3000);
        
        $names = ["status"=>"false","name1"=>$name1,"name2"=>$name2,"name3"=>$name3];
        $array = json_encode($names);
        echo $array;
    }
}
else
{
    echo "false"; //invalid post var
}
?>