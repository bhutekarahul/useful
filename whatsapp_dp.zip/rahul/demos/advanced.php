<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Responsive Crop. Advanced demos</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
        
        <script src="../libs/jquery.js" ></script>
        <script src="../dist/rcrop.min.js" ></script>
        <link href="../dist/rcrop.min.css" media="screen" rel="stylesheet" type="text/css">

        <style>
            body{margin: 0; padding: 0px}
            main{
                min-height:500px;
                display: block
            }
            pre{
                overflow: auto;
            }
            .demo{
                padding: 20px;
            }
            .image-wrapper{
                max-width: 600px;
                min-width: 200px;
            }
            img{
                max-width: 100%;
            }
            
            #image-4-wrapper .rcrop-outer-wrapper{
                opacity: .75;
            }
            #image-4-wrapper .rcrop-outer{
                background: #000
            }
            #image-4-wrapper .rcrop-croparea-inner{
                border: 1px dashed #fff;
            }
            
            #image-4-wrapper .rcrop-handler-corner{
                width:12px;
                height: 12px;
                background: none;
                border : 0 solid #51aeff;
            }
            #image-4-wrapper .rcrop-handler-top-left{
                border-top-width: 4px;
                border-left-width: 4px;
                top:-2px;
                left:-2px
            }
            #image-4-wrapper .rcrop-handler-top-right{
                border-top-width: 4px;
                border-right-width: 4px;
                top:-2px;
                right:-2px
            }
            #image-4-wrapper .rcrop-handler-bottom-right{
                border-bottom-width: 4px;
                border-right-width: 4px;
                bottom:-2px;
                right:-2px
            }
            #image-4-wrapper .rcrop-handler-bottom-left{
                border-bottom-width: 4px;
                border-left-width: 4px;
                bottom:-2px;
                left:-2px
            }
            #image-4-wrapper .rcrop-handler-border{
                display: none;
            }
            
            #image-4-wrapper .clayfy-touch-device.clayfy-handler{
                background: none;
                border : 0 solid #51aeff;
                border-bottom-width: 6px;
                border-right-width: 6px;
            }
            
            label{
                display: inline-block;
                width: 60px;
                margin-top: 10px;
            }
            #update{
                margin: 10px 0 0 60px ;
                padding: 10px 20px;
            }
            
            #cropped-original, #cropped-resized{
                padding: 20px;
                border: 4px solid #ddd;
                min-height: 60px;
                margin-top: 20px;
            }
            #cropped-original img, #cropped-resized img{
                margin: 5px;
            }

            
        </style>
        
        <script>
            $(document).ready(function(){
                
                $('#image-3').rcrop({
                    minSize : [200,200],
                    preserveAspectRatio : true,
                    
                    preview : {
                        display: true,
                        size : [200,200],
                        wrapper : '#custom-preview-wrapper'
                    }
                });
                
                $('#image-3').on('rcrop-changed', function(){
                    var srcOriginal = $(this).rcrop('getDataURL');
                    var srcResized = $(this).rcrop('getDataURL', 400,400);
//                    console.log(srcOriginal);

                    $('#cropped-original').empty();
                    $('#cropped-original').append('<img src="'+srcOriginal+'">');
//                    $('#cropImg').val(srcOriginal);
                    $('#cropImg').val(srcResized);
                });
 
            });
        </script>
        
    </head>
    <body>
        <main>
            <div class="demo">
                <h2>Set your Image</h2>

                <div class="image-wrapper">
                    <form action="upload.php" method="post" enctype="multipart/form-data" id="preview">
                        <img id="image-3" src="images/<?= $_SESSION['img'] ?>">
                        
                        <input type="hidden" value="" id="cropImg" name="cropImg"/>
                        <input type="submit" name="submit" value="Upload">
                    </form>
                    
                </div>
            </div>
        </main>

        <script>
            $(document).ready(function(){
                $('#preview').submit(function(e){
                    e.preventDefault();
                    var data = $(this).serialize();
                    $.ajax({
                       url:'http://betadelivery.com/insta/rahul/store.php' ,
                       type:'post',
                       data: data,
                       success:function(data){
                           var result = $.trim(data);
                           if(result == '1')
                               window.open('http://betadelivery.com/insta/rahul/profile.php','_self');
                           else
                               alert('something went wrong');
                       }
                    });
                });
            });
        </script>
    </body>
</html>
