<?php

$servername = "localhost";
$username = "develope_display";
$password = "RVrAHaMJc.F[";
$dbname = "develope_displaypicture";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";

