<?php

require_once  './connection.php';

$img = "SELECT `profile_image`,`original_image` FROM `profile` ORDER BY id DESC LIMIT 1 ";
$query = mysqli_query($conn,$img);
$imgName = mysqli_fetch_assoc($query);

?>
<html>
    <head>
        <style>
            .img-circular{
                border-radius: 50%;
                width: 200;
                height: 200;
            }
                
            .box{
                display: none;
            }

            a:hover + .box,.box:hover{
                display: block;
                position: relative;
                z-index: 100;
            }
            
            iframe{
                width :300 ;
                height :300;
            }
        </style>
    </head>
    <body>
<?php
    if(mysqli_num_rows($query) > 0)
    {
        echo "<a href='#'><img src='".$imgName['profile_image']."' class='img-circular'/></a>";
    }   
    else
        echo "Something went wrong";
    
?>
        
        <div class="box">
            <iframe src="<?= $imgName['profile_image'] ?>"></iframe>
        </div>
    </body>
</html>
<?php

function base64_to_jpeg($base64_string, $output_file) {
    // open the output file for writing
    $ifp = fopen( $output_file, 'wb' ); 

    // split the string on commas
    // $data[ 0 ] == "data:image/png;base64"
    // $data[ 1 ] == <actual base64 string>
    $data = explode( ',', $base64_string );

    // we could add validation here with ensuring count( $data ) > 1
    fwrite( $ifp, base64_decode( $data[ 0 ] ) );

    // clean up the file resource
    fclose( $ifp ); 

    return $output_file; 
}

$data = $imgName['profile_image'];

list($type, $data) = explode(';', $data);
list(, $data)      = explode(',', $data);

$imagename=$_SERVER['DOCUMENT_ROOT']."/insta/rahul/demos/images/".$imgName['original_image'];

$image = base64_to_jpeg( $data, $imagename );

?>



    