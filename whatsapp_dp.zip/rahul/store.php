 <?php
session_start();

include_once './connection.php';

if($_POST['cropImg'])
{
//    echo $_POST['cropImg'];
    $profile = $_POST['cropImg'];
    $original = $_SESSION['img'];
    
    $sql = "INSERT INTO `profile`(`original_image`, `profile_image`) VALUES ('$original','$profile')";
    $query = mysqli_query($conn,$sql);
    if($query == true)
        echo "1";
}
?> 